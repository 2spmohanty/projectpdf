pdfcrawl
===========================

**pdfcrawl** utility is meant for searching vast pdf files for certain policy and extract the pages where the match is found.


Getting Started
----------------------------

* Installation

The utility can be installed and run in multiple ways